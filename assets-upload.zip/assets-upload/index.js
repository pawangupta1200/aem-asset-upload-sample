const { program } = require('commander');
if(typeof require !== 'undefined') XLSX = require('xlsx');
const AemApi = require('./src/restapi');
const Utils = require('./src/nodeutils');
program
	.option('-d, --debug', 'output extra debugging')
	.option('-h, --aem-host <type>', 'aem hostname')
	.option('-c, --credentials <type>', 'aem credentials');

program.parse(process.argv);

if (program.aemHost) {
	console.log(`Axios REST test with AEM Asset integration`);
	(async () => {
		const username = program.credentials.split(":")[0];
		const password = program.credentials.split(":")[1];
		const aemApi = new AemApi(program.aemHost, username, password);
		let metadata = aemApi.getAemApiMetadata({data1: ['fly-through','animation'], data2: 'test'});
		let url = aemApi.getAemApiResourcePath("/content/dam/");
		await aemApi.put(url, metadata).then(response => {
			console.log("PUT RESULT:");
			console.log(response);
		}).catch(err => {
			console.log(err);
		});

	})();

} else {
	console.log("Error: Missing file path\n");
	console.log(program.helpInformation());
}
