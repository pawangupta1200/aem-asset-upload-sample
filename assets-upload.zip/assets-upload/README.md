# asset-upload
For bulk uploading of asset files to AEM using a CSV file

## Sample Commands
Upload of asset via nodejs
```
node bin/init aem:upload-assets -h https://<aem-hostname> -c username:<password> -i /path/to/upload.csv
```

## CSV Schema Requirements
The format requires comma separated columns.
For the import to work successfully, the csv file requires some specific column headings. The headings for defining metadata fields are optional.

### Required Headings
- **filepath**
    - The file to upload to AEM. This can be a relative or absolute path.
- **aem_target_folder**
    - The AEM location of where the file will be uploaded to. This should be some path under `/content/dam`