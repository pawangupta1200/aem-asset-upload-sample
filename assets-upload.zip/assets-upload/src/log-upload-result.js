const Path = require('path');
const config = require('./config');
const CreateReport = require('./create-report');
const CsvParser = require('./parsecsv');

/**
* @param uploadResult, uploadResult 
* @param targetFolder, targetFolder   
* @param csvDataRecieved, csvDataRecieved  
* @param recievedcsv, recievedcsv input csv file  
* @param log, log
* This function is used to create the status report incase of failure
* also used for populating csv successful column post successful upload on AEM cloud
*/
module.exports.processUploadAndLogResponse = (uploadResult, targetFolder, csvDataRecieved, recievedcsv, log) => {
    if (uploadResult !== undefined) {
        uploadResult.detailedResult.forEach(fileResult => {
            if (!fileResult.success) {
                log.info(`************* ${fileResult.fileName} ******* ${fileResult.targetPath} ****** ${fileResult.message} *******`);
                CreateReport.createReportLogs(fileResult.fileName, fileResult.targetPath, config.Notapplicable, fileResult.message);
            }
            else {
                if (fileResult.success) {
                    let dataindex = csvDataRecieved.findIndex(function (o) {
                        let filename = Path.basename(o.filepath);
                        return fileResult.fileName == filename && (o.aem_target_folder == targetFolder);
                    });
                    CsvParser.setUploadedCell(recievedcsv, csvDataRecieved[dataindex].csvRowNum);
                }
            }
        });
    }
} 