const { Command, flags } = require('@oclif/command')

class BaseCommand extends Command {
  async run() {
    return this.doRun(await this.parse());
  }
  async doRun(/* args */) {
  }

}

BaseCommand.flags = {
  version: flags.boolean({ char: 'v', description: 'Show version' }),
  help: flags.boolean({ description: 'Show help' }),
}

module.exports = BaseCommand