const Path = require('path');
const fs = require('fs');
const { flags } = require('@oclif/command');
const {
    DirectBinaryUploadOptions,
    FileSystemUpload,
} = require('@adobe/aem-upload');
const BaseCommand = require('../../base-command');
const Utils = require('../../nodeutils');
const CreateReport = require('../../create-report');
const downloadAssets = require('../../download-assets');
const deleteTempAssets = require('../../delete-temp-assets');
const config = require('../../config');
const CsvParser = require('../../parsecsv');

class UploadAssets extends BaseCommand {
    async doRun(args) {
        const { flags } = args;
        const newFlags = Object.assign({}, flags);
        const timestamp = new Date().getTime();
        Object.keys(newFlags).forEach(key => {
            if (typeof (newFlags[key]) === 'string') {
                newFlags[key] = newFlags[key].replace('${timestamp}', timestamp)
            }
        });
        const {
            host,
            credential,
            log: logFile,
            threads,
            recievedcsv,
        } = newFlags;
        const log = Utils.getLogger(logFile);
        log.info(`Processing CSV file: ${recievedcsv}`);
        const csvDataRecieved = CsvParser.readCsv(recievedcsv, "[?successful != 'true']");
        if (csvDataRecieved <= 0) {
            log.info("No Data returned from CSV file. All Assets are uploaded");
        }
        const jmespath = require('jmespath');
        let results =jmespath.search(csvDataRecieved, "[?successful.value != true]");
        if (results <= 0) {
          // log.info("No Data returned from CSV. All Assets are uploaded");
        }
        /* 
        @param csvDataRecieved, group the targer folders from aem_target_folder column
        */
        const targetFolderGroup = Utils.groupByKey(csvDataRecieved, 'aem_target_folder');
        /*  
        Object.keys(targetFolderGroup), Targetfolder
        targetFolderGroup[targetFolder], Assets details corresponding to Targetfolder
        */
        for (const targetFolder of Object.keys(targetFolderGroup)) {
            let aemFolderPath = targetFolder;
            let sourcePathDetails = targetFolderGroup[targetFolder];
           
            /* 
             @param sourcePathDetails, all details from csv 
             @param successful, get files Assets status from successful column
            */
            let assetsWithEmptyStatus = downloadAssets.getAssetStatus(sourcePathDetails, "successful");
            /* 
             @param sourcePathDetails, all details from csv 
             @param filepath, get files corresponding to targetFolder from filepath column
            */
            let downLoadImagesUrls = downloadAssets.getFields(assetsWithEmptyStatus, "filepath");
            try {
                //log.info(`Directory path: ${aemFolderPath}`);
                /* 
                Creating chunk for the assets and passing chunk one by one
                */
                let i, j, temparray, chunk = 10;
                for (i = 0, j = downLoadImagesUrls.length; i < j; i += chunk) {
                    temparray = downLoadImagesUrls.slice(i, i + chunk);
                    /**
                    * @param inputArray, inputArray of chunks urls 
                    * @param aemFolderPath, aemFolderPath of chunks urls
                    * This function is used to identify the duplicates from chunks urls
                    */
                    let uniqueUrls = downloadAssets.count_duplicate(temparray,aemFolderPath);

                    /**
                    * @param inputArray, inputArray of chunks urls 
                    * @param aemFolderPath, aemFolderPath of chunks urls
                    * This function is used to identify the duplicates from chunks urls
                    */
                   let sameAssetButDifferentSource = downloadAssets.sameAssetButDifferentSource(temparray,aemFolderPath);
                    /* 
                    Downloading files from different server or share point
                    @param downLoadImagesUrls, Assets corresponding to targetFolder 
                    @param aemFolderPath, targetFolder
                    */
                    const downloadAssest = await downloadAssets.processDownload(temparray, aemFolderPath, log);
                    log.info(`***************Downloaded: ${downloadAssest.aemFolderPath} ${downloadAssest.sourceFiles.length}`);
                    if (downloadAssest.sourceFiles.length == 0) {
                        console.log('Please correct the Empty status cells in CSV if there is any and reprocess');
                        break;
                    }

                    /* 
                    @param host, host server url
                    @param aemFolderPath
                    @param credential, to access the host server
                    */
            
                    let uploadOptions = new DirectBinaryUploadOptions()
                        .withUrl(`${Utils.trimRight(host, [config.Forward_Slash])}${downloadAssest.aemFolderPath}`)
                        .withBasicAuth(credential);
                    const fileUpload = new FileSystemUpload({ log });

                   /* 
                   @param uploadOptions
                   @param downloadAssest.sourceFiles, list of Assets
                   */
                    try {
                        log.info(`******** File Uploading started api call*****for ${downloadAssest.aemFolderPath} `);
                          log.info(`******** File Uploading  *****for **** ${host} `);
                        const fileUploadResponse = await fileUpload.upload(uploadOptions, downloadAssest.sourceFiles);
                        log.info(`******** File Uploading done *****for **** ${downloadAssest.aemFolderPath} `);
                        try {
                            let jsonResult = {};
                            jsonResult = fileUploadResponse.toJSON();
                            const logUploadResult = require('../../log-upload-result');
                            logUploadResult.processUploadAndLogResponse(jsonResult, downloadAssest.aemFolderPath, csvDataRecieved, recievedcsv);
                            try {
                                let currentDirPath = process.cwd().replace(/\\/g, "/");
                                const dir = currentDirPath + config.TempDir + downloadAssest.aemFolderPath;
                                const deleted = await deleteTempAssets.processDeleteTempAssets(dir, log);
                                log.info(`*************Deleted *************** ${deleted}`);
                                log.info(`*************Completed *************** ${downloadAssest.aemFolderPath}`);
                            } catch (error) {
                                log.error(`Error while Deleting Files: ${error}`);
                            }
                        } catch (error) {
                            log.error(`Error while Parsing Uploading response: ${error}`);
                        }
                    } catch (error) {
                        if (downloadAssest.aemFolderPath != 'empty') {
                            CreateReport.createReportLogs(downloadAssest.sourceFiles, downloadAssest.aemFolderPath, config.Notapplicable, 'Unknown Migation issue');
                        }
                        log.error(`Error while Uploading ${error}`);
                    }
                }
             } catch (error) {
                log.error(error);
            }
        };
    }
}

/* 
Getting the input Details from command Line 
*/
UploadAssets.flags = Object.assign({}, BaseCommand.flags, {
    host: flags.string({
        char: config.Host_Char,
        description: config.Host_description,
        default: config.Host_default
    }),
    credential: flags.string({
        char: config.Credential_Char,
        description: config.Credential_description,
        default: config.Credential_default
    }),
    log: flags.string({
        char: config.Log_Char,
        description: config.Log_description,
        default: config.Log_default
    }),
    threads: flags.string({
        char: config.Threads_Char,
        description: config.Threads_description,
        default: config.Threads_default
    }),
    recievedcsv: flags.string({
        char: config.Recievedcsv_Char,
        default: config.Recievedcsv_default
    }),
})

UploadAssets.strict = false;
module.exports = {
    upload: UploadAssets
}