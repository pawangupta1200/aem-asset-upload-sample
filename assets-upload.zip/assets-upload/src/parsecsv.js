if (typeof require !== 'undefined') XLSX = require('xlsx');
const jmespath = require('jmespath');
const Utils = require('./nodeutils');
module.exports.readCsv = function readCsv(csvPath, jmessearch) {
	if (csvPath) {
		const workbook = XLSX.readFile(csvPath);
		let json = XLSX.utils.sheet_to_json(workbook.Sheets.Sheet1, { defval: 'empty' });
		Object.entries(json).forEach(function ([key, value], index) {
			value.csvRowNum = value.__rowNum__;
		})
		return jmespath.search(json, jmessearch);
	} else {
		log.info("Error: Missing file path\n");
	}
}
module.exports.filterEmpty = function filterEmpty(object) {
	const obj = {};
	for (const key in object) {
		if (object[key] && object[key] !== "empty") {
			obj[key] = object[key];
		}
	}
	return obj;
}
module.exports.getTargetFolder = function getTargetFolder(jsonObject) {
	return jsonObject.aem_target_folder;
}

module.exports.getFilePath = function getFilePath(jsonObject) {
	return jsonObject.filepath;
}
module.exports.setUploadedCell = function setUploadedCell(csvPath, row) {
	if (csvPath) {
		this.updateCell(csvPath, "C", row + 1, "true"); 
	}
}

module.exports.updateCell = function updateCell(csvPath, col, row, value) {
	if (csvPath) {
		const workbook = XLSX.readFile(csvPath);
		let firstSheetName = workbook.SheetNames[0];
		let worksheet = workbook.Sheets[firstSheetName];
		let cellId = col + row;
		let cell;
		if (worksheet[cellId]) {
			cell = worksheet[cellId].v;
		}
		if (cell === 'error') {
			XLSX.utils.sheet_add_aoa(worksheet, [['error']], { origin: cellId });
		}
		else {
			XLSX.utils.sheet_add_aoa(worksheet, [[value]], { origin: cellId });
		}
		XLSX.writeFile(workbook, csvPath);
		return true;
	}
}
module.exports.filterEmpty = function filterEmpty(object) {
	const obj = {};
	for (const key in object) {
		if (object[key] && object[key] !== "empty") {
			obj[key] = object[key];
		}
	}
	return obj;
}