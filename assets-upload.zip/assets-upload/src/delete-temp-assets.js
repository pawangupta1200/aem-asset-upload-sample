const fs = require('fs');

/**
* @param path, Path details from csv 
* @param log, get files from successful column   
* This function used to delete the temp folder from Local system
*/
module.exports.processDeleteTempAssets = function deleteTempAssets(path, log) {
    return new Promise( function(resolve, reject) {
        fs.rmdir(path, { recursive: true }, (err) => {
            if (err) {
                log.error(`Error ${path}`, err);
                reject(err);
            }
            log.info(`${path} is deleted!`);
            resolve(path);
        });
    });
}