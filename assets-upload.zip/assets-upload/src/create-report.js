const fs = require('fs');
const Path = require('path');
const mustache = require('mustache');
const { config } = require('@oclif/errors');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const configuration = require('./config');
var records = [];
/* 
 @param filePath, failed files while upload
 @param TargetFolder, targert folder path
 @param err either downloaded or uploaded
*/
module.exports.createReportLogs = function createReportLogs(filePath, TargetFolder, downloaded, uploaded) {
    let jsonData = {};
    jsonData.filePath = filePath;
    jsonData.TargetFolder = TargetFolder;
    jsonData.downloaded = downloaded;
    jsonData.uploaded = uploaded;
    let currentDirPath = process.cwd().replace(/\\/g, "/");
    const timestamp = new Date().getTime();
    const logsDir = currentDirPath + '/logs'+'/detailed-status-'+timestamp+'.csv';
    const csvWriter = createCsvWriter({
        path: logsDir,
        header: [
            { id: 'filePath', title: 'FilePath' },
            { id: 'TargetFolder', title: 'Target' },
            { id: 'downloaded', title: 'Download status' },
            { id: 'uploaded', title: 'Upload status' }
        ]
    });

    records.push(jsonData);
    /*
        @param records, contains error records in json
        This returns a promise 
    */
    csvWriter.writeRecords(records)
        .then(() => {
            console.log('Failed items are logged in status report');
        });
}