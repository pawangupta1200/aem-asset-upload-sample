/**
 * @link   
 * @file   This files defines downloading of the files from csv.
 * @author Neelesh.kumar.dixit.
 * @since  
 */ 
const fs = require('fs');
const Path = require('path');
var request = require('request');
const CreateReport = require('./create-report');
const config = require('./config');
const urlExist = require("url-exist");

/**
* @param dir, directory 
* This function is used to create the directory as per the target folder path
*/
const createDir = (dir) => {
    const splitPath = dir.split(config.Forward_Slash);
    splitPath.reduce((path, subPath) => {
        let currentPath;
        if (subPath != '.') {
            currentPath = path + config.Forward_Slash + subPath;
            if (!fs.existsSync(currentPath)) {
                fs.mkdirSync(currentPath);
            }
        }
        else {
            currentPath = subPath;
        }
        return currentPath;
    }, '');
}

/**
* @param inputArray, inputArray of chunks urls 
* @param aemFolderPath, aemFolderPath of chunks urls
* This function is used to identify the duplicates from chunks urls
*/
module.exports.count_duplicate = function count_duplicate(inputArray, aemFolderPath) {
    let counts = {};
    for (let i = 0; i < inputArray.length; i++) {
        if (counts[inputArray[i]]) {
            counts[inputArray[i]] += 1;
        } else {
            counts[inputArray[i]] = 1;
        }
    }
    for (let prop in counts) {
        if (counts[prop] >= 2) {
            if (!(prop.startsWith(config.Https) || prop.startsWith(config.Http))) {
                fs.stat(prop, function (err, stat) {
                    if (err == null) {
                        CreateReport.createReportLogs(prop, aemFolderPath, config.Duplicate + counts[prop] + config.Times, config.Notapplicable);
                    }
                }
                )
            }
            else {
                (async () => {
                    var request = require('request');
                    request({
                        'url': prop,
                        'method': "GET",
                      //  'proxy': config.https_proxy
                    }, function (error, response, body) {
                        if (!error && response.statusCode == 200) {
                            let fileType = Path.extname(prop);
                            if ((fileType != null && config.fileTypesArray.includes(fileType))) {
                                CreateReport.createReportLogs(prop, aemFolderPath, config.Duplicate, config.Notapplicable);
                            }
                        }
                    })
                })();
            }
        }
    }
}

/**
* @param inputArray, inputArray of chunks urls 
* @param aemFolderPath, aemFolderPath of chunks urls
* @author Neelesh.kumar.dixit
* This function is used to identify the same Asset Name But Different Source urls
*/

module.exports.sameAssetButDifferentSource = function sameAssetButDifferentSource(inputArray, aemFolderPath) {
    let counts = {};
    let tempArray = [];
    for (let i = 0; i < inputArray.length; i++) {
        let assetsURLs = inputArray[i].split(config.Forward_Slash).pop();
        tempArray.push(assetsURLs);
    }
    for (let i = 0; i < tempArray.length; i++) {
        if (counts[tempArray[i]]) {
            counts[tempArray[i]] += 1;
        } else {
            counts[tempArray[i]] = 1;
        }
    }
    for (let prop in counts) {
        if (counts[prop] >= 2) {
            CreateReport.createReportLogs(prop, aemFolderPath, 'File Name already exists ' + config.Duplicate + counts[prop] + config.Times, config.Notapplicable);
        }
    }
}

/**
* @param input, source Path details from csv 
* @param field, get files from successful column   
* This function is used to extract the assets status from input Json
*/
module.exports.getAssetStatus = function getAssetStatus(input, field) {
    var output = [];
    for (let i = 0; i < input.length; ++i)
        if (input[i][field] == 'empty') {
            output.push(input[i]);
        } else {
            // console.log(`Already set True`);
        }
    return output;
}

/**
* @param input, source Path details from csv 
* @param field, get files from filepath column   
* This function is used to extract the assets urls from the input Json
*/
module.exports.getFields = function getFields(input, field) {
    var output = [];
    for (let i = 0; i < input.length; ++i)
        output.push(input[i][field]);
    return output;
}

/**
* @param imagesUrlsList,Urls to download 
* @param aemFolderPath,targetFolder  
* @param log,log 
* This function handle downloading in Temp directory from http/sharepoint
*/
module.exports.processDownload = function processDownload(imagesUrlsList, aemFolderPath, log) {
    let urlList = imagesUrlsList;
    let dir = config.Temp + aemFolderPath;
    createDir(dir);
    let counter = 0;
    let result = [];
    if (aemFolderPath == 'empty') {
        CreateReport.createReportLogs(urlList, aemFolderPath, config.Target_Path_Empty, config.Notapplicable);
    }
    return new Promise(function (resolve, reject) {
        /**
         * @param url, Requested asset url from http 
         * @param dest, local directory under temp to create 
         * @param callback, callback   
         * This function is used to download the assets from http urls to local Temp directory
         * by creating Target Folder path inside Temp directory
         */
        let download = function (url, dest, callback) {
            let fileType = Path.extname(url);
            const targetPath = dest.substr(0, dest.lastIndexOf('/')).replace(config.Temp, '');
            if (!(fileType != null && config.fileTypesArray.includes(fileType))) {
                CreateReport.createReportLogs(url, targetPath, fileType + config.Not_Supported, config.Notapplicable);
                callback('fileType error');
            } else {
                try {
                    let request = require('request');
                    request({
                        'url': url,
                        'method': "GET",
                        // 'proxy': config.https_proxy
                    }, function (error, response, body) {
                        if (!error && response.statusCode == 200) {
                            (async () => {
                                if (true) {
                                    await new Promise((resolve, reject) => {
                                        let stream = request({
                                            uri: url,
                                           // 'proxy': config.https_proxy,
                                            'method': "GET",
                                            headers: {
                                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                                                'Accept-Encoding': 'gzip, deflate, br',
                                                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,ro;q=0.7,ru;q=0.6,la;q=0.5,pt;q=0.4,de;q=0.3',
                                                'Cache-Control': 'max-age=0',
                                                'Connection': 'keep-alive',
                                                'Upgrade-Insecure-Requests': '1',
                                                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'
                                            },
                                            gzip: false
                                        })
                                            .pipe(fs.createWriteStream(dest))
                                            .on('finish', () => {
                                                resolve();
                                                result.push(dest);
                                                let fileArray = [];
                                                fileArray.push(dest);
                                                for (let i = 0; i < fileArray.length; ++i) {
                                                    let fileStat = fs.statSync(fileArray[i]);
                                                    if (fileStat.size === 0) {
                                                        CreateReport.createReportLogs(url, targetPath, 'canot process 0 file size', config.Notapplicable);
                                                    }
                                                    callback('resolved'); 
                                                }
                                            })
                                            .on('error', (error) => {
                                                CreateReport.createReportLogs(url, targetPath, error, config.Notapplicable);
                                                reject(error);
                                                callback(null, error);
                                            })
                                    })
                                        .catch(error => {
                                            console.log(`Error occured: ${error}`);
                                            CreateReport.createReportLogs(url, targetPath, config.INVALID_URL, config.Notapplicable);
                                            callback(error);
                                        });
                                }
                            })();
                        }
                        else {
                            CreateReport.createReportLogs(url, targetPath, config.INVALID_URL, config.Notapplicable);
                            validUrls = false;
                            callback('error');
                        }
                    })
                } catch (error) {
                    CreateReport.createReportLogs(url, targetPath, config.INVALID_URL, config.Notapplicable);
                    callback(error);
                }
            }
        }

        /**
         * 
         * @param str, Requested asset url from sharepoint
         * @param targetDirPath, local directory under temp to create
         * @param cb, callback
         * This function is used to download the assets from sharepoint urls to local Temp directory
         * by creating Target Folder path inside Temp directory
         */
        function sharepointDownload(str, targetDirPath, cb) {
            let filepath = str.replace(/\\/g, "/");
            str=str.replace(/[]/g,'•');
            let fileType = Path.extname(filepath);
            fs.stat(str, function (err, stat) {
                    if (err == null) {
                    if (config.fileTypesArray.includes(fileType)) {
                        let readPath = fs.createReadStream(str);
                        let writePath = fs.createWriteStream(targetDirPath);
                        try {
                            log.info(`sharepointDownload starts`);
                            return new Promise(function (resolve, reject) {
                                readPath.on('error', function (err) {
                                    CreateReport.createReportLogs(str, aemFolderPath, err, config.Notapplicable);
                                    cb(err);
                                });
                                writePath.on('error', function (err) {
                                    CreateReport.createReportLogs(str, aemFolderPath, err, config.Notapplicable);
                                    cb(err);
                                });
                                writePath.on('finish', () => {
                                    result.push(targetDirPath);
                                    cb(null, resolve());
                                });
                                readPath.pipe(writePath);
                                log.info(`sharepointDownload Url exists: ${str}`);
                            });
                        } catch (error) {
                            readPath.destroy();
                            writePath.end();
                            console.log('Error in downloading file', error);
                            cb(error);
                        }
                    }
                    else {
                        cb('Invaid file type');
                    }
                } else {
                    let message = config.INVALID_URL;
                    if (!(fileType != null && config.fileTypesArray.includes(fileType))) {
                        message = fileType + config.Not_Supported;
                    }
                    CreateReport.createReportLogs(str, aemFolderPath, message, config.Notapplicable);
                    cb(err);
                }
            });

        }
        for (const str of urlList) {
            let filename = dir + config.Forward_Slash + str.split(config.Forward_Slash).pop();
            if (!(str.startsWith(config.Https) || str.startsWith(config.Http))) {
                sharepointDownload(str, filename, function () {
                    counter++;
                    if (urlList.length === counter) {
                        resolve({ aemFolderPath, sourceFiles: result });
                    }
                });
            }
            else {
                download(str, filename, function () {
                    counter++;
                    if (urlList.length === counter) {
                        resolve({ aemFolderPath, sourceFiles: result });
                    }
                });
            }
        };
    });
}